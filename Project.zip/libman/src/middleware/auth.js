const Member = require('../models/Member');
const { verifyToken } = require('../utils/token');
const asyncHandler = require('./asyncHandler');
const { httpError } = require('./errorHandler');

const protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) throw httpError(401, 'Authentication required');

  let payload;
  try {
    payload = verifyToken(header.slice(7));
  } catch (_) {
    throw httpError(401, 'Invalid or expired token');
  }

  const member = await Member.findById(payload.id);
  if (!member) throw httpError(401, 'Account no longer exists');
  if (member.status !== 'active') throw httpError(403, 'Account is inactive');

  req.user = member;
  next();
});

function adminOnly(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return next(httpError(403, 'Admin access required'));
  }
  next();
}

module.exports = { protect, adminOnly };
