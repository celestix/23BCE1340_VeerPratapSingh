require('dotenv').config();

const { connectDB, disconnectDB } = require('../config/db');
const Book = require('../models/Book');
const Member = require('../models/Member');
const Loan = require('../models/Loan');

const books = [
  { title: 'The Pragmatic Programmer', author: 'Andrew Hunt', isbn: '978-0135957059', category: 'Programming', publishedYear: 2019, totalCopies: 3 },
  { title: 'Clean Code', author: 'Robert C. Martin', isbn: '978-0132350884', category: 'Programming', publishedYear: 2008, totalCopies: 2 },
  { title: 'MongoDB: The Definitive Guide', author: 'Shannon Bradshaw', isbn: '978-1491954461', category: 'Databases', publishedYear: 2019, totalCopies: 4 },
  { title: 'Designing Data-Intensive Applications', author: 'Martin Kleppmann', isbn: '978-1449373320', category: 'Databases', publishedYear: 2017, totalCopies: 2 },
  { title: 'Sapiens', author: 'Yuval Noah Harari', isbn: '978-0062316097', category: 'History', publishedYear: 2015, totalCopies: 5 },
];

const members = [
  { name: 'Admin', email: 'admin@example.com', phone: '555-0100', role: 'admin', password: 'admin123' },
  { name: 'Alice Johnson', email: 'alice@example.com', phone: '555-0101', password: 'password123' },
  { name: 'Bob Smith', email: 'bob@example.com', phone: '555-0102', password: 'password123' },
  { name: 'Carol Williams', email: 'carol@example.com', phone: '555-0103', status: 'inactive', password: 'password123' },
];

async function seed() {
  await connectDB();
  console.log('Clearing existing data...');
  await Promise.all([Loan.deleteMany({}), Book.deleteMany({}), Member.deleteMany({})]);

  const createdBooks = await Book.insertMany(books);
  const createdMembers = [];
  for (const { password, ...fields } of members) {
    const member = new Member(fields);
    member.setPassword(password);
    createdMembers.push(await member.save());
  }
  console.log(`Inserted ${createdBooks.length} books and ${createdMembers.length} members (admin@example.com / admin123).`);

  const due = new Date();
  due.setDate(due.getDate() + 14);
  await Book.updateOne({ _id: createdBooks[0]._id }, { $inc: { availableCopies: -1 } });
  await Loan.create({ book: createdBooks[0]._id, member: createdMembers[1]._id, dueDate: due });
  console.log('Created 1 sample loan.');

  await disconnectDB();
  console.log('Seed complete.');
}

if (require.main === module) {
  seed().catch(async (err) => {
    console.error('Seed failed:', err.message);
    await disconnectDB().catch(() => {});
    process.exit(1);
  });
}

module.exports = seed;
