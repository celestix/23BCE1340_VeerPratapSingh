const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const memberSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: [120, 'Name cannot exceed 120 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      trim: true,
      lowercase: true,
      unique: true,
      match: [EMAIL_REGEX, 'Email format is invalid'],
    },
    phone: {
      type: String,
      trim: true,
      default: '',
      maxlength: [30, 'Phone cannot exceed 30 characters'],
    },
    membershipId: {
      type: String,
      unique: true,
      trim: true,
      uppercase: true,
    },
    role: {
      type: String,
      enum: {
        values: ['member', 'admin'],
        message: 'Role must be either "member" or "admin"',
      },
      default: 'member',
    },
    passwordHash: {
      type: String,
      select: false,
    },
    status: {
      type: String,
      enum: {
        values: ['active', 'inactive'],
        message: 'Status must be either "active" or "inactive"',
      },
      default: 'active',
    },
    joinedDate: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

memberSchema.pre('validate', function generateMembershipId(next) {
  if (!this.membershipId) {
    const random = Math.floor(1000 + Math.random() * 9000);
    this.membershipId = `LIB-${Date.now().toString(36).toUpperCase()}-${random}`;
  }
  next();
});

memberSchema.pre('save', async function hashPassword(next) {
  if (this._password) {
    this.passwordHash = await bcrypt.hash(this._password, 10);
    this._password = undefined;
  }
  next();
});

memberSchema.methods.setPassword = function setPassword(plain) {
  this._password = plain;
};

memberSchema.methods.matchPassword = function matchPassword(plain) {
  if (!this.passwordHash) return Promise.resolve(false);
  return bcrypt.compare(plain, this.passwordHash);
};

memberSchema.set('toJSON', {
  transform(doc, ret) {
    delete ret.passwordHash;
    return ret;
  },
});

module.exports = mongoose.model('Member', memberSchema);
