const mongoose = require('mongoose');

const CURRENT_YEAR = new Date().getFullYear();

const bookSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters'],
    },
    author: {
      type: String,
      required: [true, 'Author is required'],
      trim: true,
      maxlength: [120, 'Author cannot exceed 120 characters'],
    },
    isbn: {
      type: String,
      required: [true, 'ISBN is required'],
      trim: true,
      unique: true,
      match: [/^[0-9Xx][0-9Xx \-]{8,18}$/, 'ISBN format is invalid'],
    },
    category: {
      type: String,
      trim: true,
      default: 'General',
      maxlength: [60, 'Category cannot exceed 60 characters'],
    },
    publishedYear: {
      type: Number,
      min: [1450, 'Published year seems too early'],
      max: [CURRENT_YEAR + 1, 'Published year cannot be in the far future'],
    },
    totalCopies: {
      type: Number,
      default: 1,
      min: [0, 'Total copies cannot be negative'],
      validate: {
        validator: Number.isInteger,
        message: 'Total copies must be a whole number',
      },
    },
    availableCopies: {
      type: Number,
      min: [0, 'Available copies cannot be negative'],
      validate: {
        validator: Number.isInteger,
        message: 'Available copies must be a whole number',
      },
    },
    description: {
      type: String,
      trim: true,
      default: '',
      maxlength: [1000, 'Description cannot exceed 1000 characters'],
    },
  },
  { timestamps: true }
);

bookSchema.pre('validate', function defaultAvailableCopies(next) {
  if (this.availableCopies === undefined || this.availableCopies === null) {
    this.availableCopies = this.totalCopies;
  }
  if (
    typeof this.totalCopies === 'number' &&
    typeof this.availableCopies === 'number' &&
    this.availableCopies > this.totalCopies
  ) {
    this.invalidate('availableCopies', 'Available copies cannot exceed total copies');
  }
  next();
});

bookSchema.index({ title: 'text', author: 'text' });

module.exports = mongoose.model('Book', bookSchema);
