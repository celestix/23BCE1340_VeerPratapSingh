const express = require('express');
const {
  listBooks,
  getBook,
  createBook,
  updateBook,
  deleteBook,
} = require('../controllers/bookController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.route('/').get(listBooks).post(adminOnly, createBook);
router.route('/:id').get(getBook).put(adminOnly, updateBook).delete(adminOnly, deleteBook);

module.exports = router;
