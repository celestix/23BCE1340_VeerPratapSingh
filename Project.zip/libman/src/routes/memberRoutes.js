const express = require('express');
const {
  listMembers,
  getMember,
  createMember,
  updateMember,
  deleteMember,
} = require('../controllers/memberController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

router.use(protect, adminOnly);

router.route('/').get(listMembers).post(createMember);
router.route('/:id').get(getMember).put(updateMember).delete(deleteMember);

module.exports = router;
