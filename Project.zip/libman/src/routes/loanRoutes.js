const express = require('express');
const {
  listLoans,
  getLoan,
  issueBook,
  borrowBook,
  returnBook,
} = require('../controllers/loanController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.post('/borrow', borrowBook);
router.route('/').get(listLoans).post(adminOnly, issueBook);
router.get('/:id', getLoan);
router.post('/:id/return', returnBook);

module.exports = router;
