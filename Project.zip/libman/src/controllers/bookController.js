const Book = require('../models/Book');
const Loan = require('../models/Loan');
const asyncHandler = require('../middleware/asyncHandler');
const { httpError } = require('../middleware/errorHandler');

const CREATE_FIELDS = ['title', 'author', 'isbn', 'category', 'publishedYear', 'totalCopies', 'description'];
const UPDATE_FIELDS = ['title', 'author', 'isbn', 'category', 'publishedYear', 'description'];

function pick(source, fields) {
  return fields.reduce((acc, key) => {
    if (source[key] !== undefined) acc[key] = source[key];
    return acc;
  }, {});
}

const listBooks = asyncHandler(async (req, res) => {
  const filter = {};

  if (req.query.search) {
    const term = new RegExp(String(req.query.search).trim(), 'i');
    filter.$or = [{ title: term }, { author: term }, { isbn: term }];
  }

  if (req.query.available === 'true') {
    filter.availableCopies = { $gt: 0 };
  }

  const books = await Book.find(filter).sort({ createdAt: -1 });
  res.json({ success: true, count: books.length, data: books });
});

const getBook = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) throw httpError(404, 'Book not found');
  res.json({ success: true, data: book });
});

const createBook = asyncHandler(async (req, res) => {
  const book = await Book.create(pick(req.body, CREATE_FIELDS));
  res.status(201).json({ success: true, data: book });
});

const updateBook = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) throw httpError(404, 'Book not found');

  Object.assign(book, pick(req.body, UPDATE_FIELDS));

  if (req.body.totalCopies !== undefined) {
    const newTotal = Number(req.body.totalCopies);
    const onLoan = book.totalCopies - book.availableCopies;
    if (Number.isInteger(newTotal) && newTotal >= 0) {
      if (newTotal < onLoan) {
        throw httpError(409, `Cannot set total to ${newTotal}; ${onLoan} copies are currently on loan`);
      }
      book.totalCopies = newTotal;
      book.availableCopies = newTotal - onLoan;
    } else {
      book.totalCopies = req.body.totalCopies;
    }
  }

  await book.save();
  res.json({ success: true, data: book });
});

const deleteBook = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) throw httpError(404, 'Book not found');

  const activeLoans = await Loan.countDocuments({ book: book._id, status: 'issued' });
  if (activeLoans > 0) {
    throw httpError(409, `Cannot delete: ${activeLoans} copy/copies are currently on loan`);
  }

  await book.deleteOne();
  res.json({ success: true, data: { id: book._id } });
});

module.exports = { listBooks, getBook, createBook, updateBook, deleteBook };
