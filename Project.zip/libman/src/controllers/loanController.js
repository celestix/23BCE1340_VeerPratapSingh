const mongoose = require('mongoose');
const Loan = require('../models/Loan');
const Book = require('../models/Book');
const Member = require('../models/Member');
const asyncHandler = require('../middleware/asyncHandler');
const { httpError } = require('../middleware/errorHandler');

const POPULATE = [
  { path: 'book', select: 'title isbn author' },
  { path: 'member', select: 'name membershipId email' },
];

function defaultDueDate() {
  const days = Number(process.env.LOAN_PERIOD_DAYS) || 14;
  const due = new Date();
  due.setDate(due.getDate() + days);
  return due;
}

function isAdmin(req) {
  return req.user && req.user.role === 'admin';
}

async function issueLoan(bookId, memberId, dueDateInput) {
  if (!mongoose.isValidObjectId(bookId)) throw httpError(400, 'A valid bookId is required');
  if (!mongoose.isValidObjectId(memberId)) throw httpError(400, 'A valid memberId is required');

  const member = await Member.findById(memberId);
  if (!member) throw httpError(404, 'Member not found');
  if (member.status !== 'active') throw httpError(409, 'Member is not active and cannot borrow books');

  const book = await Book.findById(bookId);
  if (!book) throw httpError(404, 'Book not found');

  let dueDate = defaultDueDate();
  if (dueDateInput !== undefined) {
    const parsed = new Date(dueDateInput);
    if (Number.isNaN(parsed.getTime())) throw httpError(400, 'dueDate is not a valid date');
    dueDate = parsed;
  }

  const claimed = await Book.findOneAndUpdate(
    { _id: bookId, availableCopies: { $gt: 0 } },
    { $inc: { availableCopies: -1 } },
    { new: true }
  );
  if (!claimed) throw httpError(409, 'No copies of this book are currently available');

  try {
    const loan = await Loan.create({ book: bookId, member: memberId, dueDate });
    return loan.populate(POPULATE);
  } catch (err) {
    await Book.updateOne({ _id: bookId }, { $inc: { availableCopies: 1 } });
    throw err;
  }
}

const listLoans = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.status) filter.status = req.query.status;

  if (isAdmin(req)) {
    if (req.query.member && mongoose.isValidObjectId(req.query.member)) filter.member = req.query.member;
    if (req.query.book && mongoose.isValidObjectId(req.query.book)) filter.book = req.query.book;
  } else {
    filter.member = req.user._id;
  }

  const loans = await Loan.find(filter).populate(POPULATE).sort({ createdAt: -1 });
  res.json({ success: true, count: loans.length, data: loans });
});

const getLoan = asyncHandler(async (req, res) => {
  const loan = await Loan.findById(req.params.id).populate(POPULATE);
  if (!loan) throw httpError(404, 'Loan not found');
  if (!isAdmin(req) && String(loan.member?._id) !== String(req.user._id)) {
    throw httpError(403, 'You can only view your own loans');
  }
  res.json({ success: true, data: loan });
});

const issueBook = asyncHandler(async (req, res) => {
  const loan = await issueLoan(req.body.bookId, req.body.memberId, req.body.dueDate);
  res.status(201).json({ success: true, data: loan });
});

const borrowBook = asyncHandler(async (req, res) => {
  const loan = await issueLoan(req.body.bookId, req.user._id, req.body.dueDate);
  res.status(201).json({ success: true, data: loan });
});

const returnBook = asyncHandler(async (req, res) => {
  const loan = await Loan.findById(req.params.id);
  if (!loan) throw httpError(404, 'Loan not found');
  if (!isAdmin(req) && String(loan.member) !== String(req.user._id)) {
    throw httpError(403, 'You can only return your own loans');
  }
  if (loan.status === 'returned') throw httpError(409, 'This loan has already been returned');

  loan.status = 'returned';
  loan.returnDate = new Date();
  await loan.save();

  await Book.findOneAndUpdate(
    { _id: loan.book, $expr: { $lt: ['$availableCopies', '$totalCopies'] } },
    { $inc: { availableCopies: 1 } }
  );

  const populated = await loan.populate(POPULATE);
  res.json({ success: true, data: populated });
});

module.exports = { listLoans, getLoan, issueBook, borrowBook, returnBook };
