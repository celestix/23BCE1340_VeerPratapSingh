const Member = require('../models/Member');
const Loan = require('../models/Loan');
const asyncHandler = require('../middleware/asyncHandler');
const { httpError } = require('../middleware/errorHandler');

const CREATE_FIELDS = ['name', 'email', 'phone', 'status', 'role'];
const UPDATE_FIELDS = ['name', 'email', 'phone', 'status', 'role'];

function pick(source, fields) {
  return fields.reduce((acc, key) => {
    if (source[key] !== undefined) acc[key] = source[key];
    return acc;
  }, {});
}

const listMembers = asyncHandler(async (req, res) => {
  const filter = {};

  if (req.query.search) {
    const term = new RegExp(String(req.query.search).trim(), 'i');
    filter.$or = [{ name: term }, { email: term }, { membershipId: term }];
  }

  if (req.query.status) {
    filter.status = req.query.status;
  }

  const members = await Member.find(filter).sort({ createdAt: -1 });
  res.json({ success: true, count: members.length, data: members });
});

const getMember = asyncHandler(async (req, res) => {
  const member = await Member.findById(req.params.id);
  if (!member) throw httpError(404, 'Member not found');
  res.json({ success: true, data: member });
});

const createMember = asyncHandler(async (req, res) => {
  const member = new Member(pick(req.body, CREATE_FIELDS));
  if (req.body.password) member.setPassword(String(req.body.password));
  await member.save();
  res.status(201).json({ success: true, data: member });
});

const updateMember = asyncHandler(async (req, res) => {
  const member = await Member.findById(req.params.id);
  if (!member) throw httpError(404, 'Member not found');

  Object.assign(member, pick(req.body, UPDATE_FIELDS));
  if (req.body.password) member.setPassword(String(req.body.password));
  await member.save();
  res.json({ success: true, data: member });
});

const deleteMember = asyncHandler(async (req, res) => {
  const member = await Member.findById(req.params.id);
  if (!member) throw httpError(404, 'Member not found');

  const activeLoans = await Loan.countDocuments({ member: member._id, status: 'issued' });
  if (activeLoans > 0) {
    throw httpError(409, `Cannot delete: member has ${activeLoans} active loan(s)`);
  }

  await member.deleteOne();
  res.json({ success: true, data: { id: member._id } });
});

module.exports = { listMembers, getMember, createMember, updateMember, deleteMember };
