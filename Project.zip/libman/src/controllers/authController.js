const Member = require('../models/Member');
const asyncHandler = require('../middleware/asyncHandler');
const { httpError } = require('../middleware/errorHandler');
const { signToken } = require('../utils/token');

const PASSWORD_MIN = 6;
const PASSWORD_MAX = 128;

function validatePassword(password) {
  if (typeof password !== 'string' || password.length < PASSWORD_MIN) {
    throw httpError(400, `Password must be at least ${PASSWORD_MIN} characters`);
  }
  if (password.length > PASSWORD_MAX) {
    throw httpError(400, `Password cannot exceed ${PASSWORD_MAX} characters`);
  }
}

function authResponse(res, status, member) {
  const token = signToken({ id: member._id, role: member.role });
  res.status(status).json({
    success: true,
    token,
    data: {
      id: member._id,
      name: member.name,
      email: member.email,
      role: member.role,
      membershipId: member.membershipId,
    },
  });
}

const register = asyncHandler(async (req, res) => {
  const { name, email, phone, password } = req.body;
  validatePassword(password);

  const member = new Member({ name, email, phone, role: 'member' });
  member.setPassword(password);
  await member.save();

  authResponse(res, 201, member);
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) throw httpError(400, 'Email and password are required');

  const member = await Member.findOne({ email: String(email).toLowerCase() }).select('+passwordHash');
  if (!member || !(await member.matchPassword(password))) {
    throw httpError(401, 'Invalid email or password');
  }
  if (member.status !== 'active') throw httpError(403, 'Account is inactive');

  authResponse(res, 200, member);
});

const me = asyncHandler(async (req, res) => {
  res.json({ success: true, data: req.user });
});

module.exports = { register, login, me };
