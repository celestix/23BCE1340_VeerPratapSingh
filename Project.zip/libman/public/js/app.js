'use strict';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const TOKEN_KEY = 'libman_token';
const USER_KEY = 'libman_user';

const getToken = () => localStorage.getItem(TOKEN_KEY);
const setSession = (token, user) => {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};
const clearSession = () => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function toast(message, type = '') {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast show ${type}`;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (el.className = 'toast'), 3200);
}

const debounce = (fn, ms = 300) => {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
};

function formToObject(form) {
  const data = {};
  new FormData(form).forEach((value, key) => {
    const trimmed = typeof value === 'string' ? value.trim() : value;
    if (trimmed !== '') data[key] = trimmed;
  });
  return data;
}

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`/api${path}`, { ...options, headers });
  let body = {};
  try {
    body = await res.json();
  } catch (_) {
  }
  if (res.status === 401 && getToken()) {
    logout();
    throw new Error(body.error || 'Session expired, please log in again');
  }
  if (!res.ok || body.success === false) {
    const detail = body.details ? `: ${body.details.join(', ')}` : '';
    throw new Error((body.error || `Request failed (${res.status})`) + detail);
  }
  return body;
}

$$('.auth-tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    $$('.auth-tab').forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    const isLogin = tab.dataset.authTab === 'login';
    $('#login-form').hidden = !isLogin;
    $('#register-form').hidden = isLogin;
  });
});

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const { token, data } = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify(formToObject(e.target)),
    });
    setSession(token, data);
    enterApp(data);
    toast(`Welcome, ${data.name}`, 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
});

$('#register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const { token, data } = await api('/auth/register', {
      method: 'POST',
      body: JSON.stringify(formToObject(e.target)),
    });
    setSession(token, data);
    enterApp(data);
    toast(`Account created - welcome, ${data.name}`, 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
});

$('#logout-btn').addEventListener('click', logout);

function logout() {
  clearSession();
  $('#app-view').hidden = true;
  $('#auth-view').hidden = false;
}

function showAuth() {
  $('#app-view').hidden = true;
  $('#auth-view').hidden = false;
}

function enterApp(user) {
  $('#auth-view').hidden = true;
  $('#app-view').hidden = false;
  $('#user-name').textContent = user.name;
  const roleBadge = $('#user-role');
  roleBadge.textContent = user.role;
  roleBadge.className = `badge badge-${user.role === 'admin' ? 'issued' : 'active'}`;

  const role = user.role;
  $$('#nav .tab').forEach((t) => (t.hidden = t.dataset.roles !== role));
  $$('main .panel').forEach((p) => (p.hidden = p.dataset.roles !== role));

  const firstTab = $$('#nav .tab').find((t) => !t.hidden);
  if (firstTab) activateTab(firstTab.dataset.tab);

  if (role === 'admin') {
    loadBooks();
    loadMembers();
    loadLoans();
  } else {
    loadBrowse();
    loadMyLoans();
  }
}

function activateTab(name) {
  $$('#nav .tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  $$('main .panel').forEach((p) => p.classList.toggle('active', p.id === name));
  if (name === 'loans') loadLoanFormOptions();
}

$$('#nav .tab').forEach((tab) => tab.addEventListener('click', () => activateTab(tab.dataset.tab)));

$$('[data-reset]').forEach((btn) =>
  btn.addEventListener('click', () => resetForm(btn.dataset.reset))
);

function resetForm(formId) {
  const form = $(`#${formId}`);
  form.reset();
  form.elements.id.value = '';
  if (formId === 'book-form') $('#book-form-title').textContent = 'Add Book';
  if (formId === 'member-form') $('#member-form-title').textContent = 'Add Member';
}

async function loadBrowse(search = '') {
  try {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    const { data } = await api(`/books${q}`);
    const body = $('#browse-body');
    if (!data.length) {
      body.innerHTML = '<tr><td colspan="4" class="empty">No books found.</td></tr>';
      return;
    }
    body.innerHTML = data
      .map((b) => {
        const can = b.availableCopies > 0;
        const btn = can
          ? `<button class="btn btn-primary btn-sm" data-borrow="${b._id}">Borrow</button>`
          : '<span class="badge badge-zero">out of stock</span>';
        return `<tr>
          <td>${escapeHtml(b.title)}</td>
          <td>${escapeHtml(b.author)}</td>
          <td>${b.availableCopies} / ${b.totalCopies}</td>
          <td><div class="actions">${btn}</div></td>
        </tr>`;
      })
      .join('');
    $$('[data-borrow]', body).forEach((btn) =>
      btn.addEventListener('click', () => borrow(btn.dataset.borrow))
    );
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function borrow(bookId) {
  try {
    await api('/loans/borrow', { method: 'POST', body: JSON.stringify({ bookId }) });
    toast('Book borrowed', 'success');
    loadBrowse($('[data-search="browse"]').value);
    loadMyLoans();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadMyLoans() {
  try {
    const { data } = await api('/loans');
    const body = $('#myloans-body');
    if (!data.length) {
      body.innerHTML = '<tr><td colspan="5" class="empty">You have no loans.</td></tr>';
      return;
    }
    body.innerHTML = data
      .map((l) => {
        const book = l.book ? l.book.title : '(deleted book)';
        const issued = new Date(l.issueDate).toLocaleDateString();
        const due = new Date(l.dueDate).toLocaleDateString();
        let badge = `<span class="badge badge-${l.status}">${l.status}</span>`;
        if (l.isOverdue) badge = '<span class="badge badge-overdue">overdue</span>';
        const action =
          l.status === 'issued'
            ? `<button class="btn-link btn-return" data-return="${l._id}">Return</button>`
            : '';
        return `<tr>
          <td>${escapeHtml(book)}</td>
          <td>${escapeHtml(issued)}</td>
          <td>${escapeHtml(due)}</td>
          <td>${badge}</td>
          <td><div class="actions">${action}</div></td>
        </tr>`;
      })
      .join('');
    $$('[data-return]', body).forEach((btn) =>
      btn.addEventListener('click', () => returnLoan(btn.dataset.return, true))
    );
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadBooks(search = '') {
  try {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    const { data } = await api(`/books${q}`);
    const body = $('#books-body');
    if (!data.length) {
      body.innerHTML = '<tr><td colspan="5" class="empty">No books yet.</td></tr>';
      return;
    }
    body.innerHTML = data
      .map((b) => {
        const availClass = b.availableCopies === 0 ? 'badge badge-zero' : '';
        return `<tr>
          <td>${escapeHtml(b.title)}</td>
          <td>${escapeHtml(b.author)}</td>
          <td>${escapeHtml(b.isbn)}</td>
          <td><span class="${availClass}">${b.availableCopies} / ${b.totalCopies}</span></td>
          <td><div class="actions">
            <button class="btn-link btn-edit" data-edit-book='${escapeHtml(JSON.stringify(b))}'>Edit</button>
            <button class="btn-link btn-del" data-del-book="${b._id}">Delete</button>
          </div></td>
        </tr>`;
      })
      .join('');
    $$('[data-edit-book]', body).forEach((btn) =>
      btn.addEventListener('click', () => fillBookForm(JSON.parse(btn.dataset.editBook)))
    );
    $$('[data-del-book]', body).forEach((btn) =>
      btn.addEventListener('click', () => deleteBook(btn.dataset.delBook))
    );
  } catch (err) {
    toast(err.message, 'error');
  }
}

function fillBookForm(book) {
  const f = $('#book-form');
  f.elements.id.value = book._id;
  f.elements.title.value = book.title;
  f.elements.author.value = book.author;
  f.elements.isbn.value = book.isbn;
  f.elements.category.value = book.category || '';
  f.elements.publishedYear.value = book.publishedYear || '';
  f.elements.totalCopies.value = book.totalCopies;
  f.elements.description.value = book.description || '';
  $('#book-form-title').textContent = 'Edit Book';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

$('#book-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = formToObject(e.target);
  const id = payload.id;
  delete payload.id;
  if (payload.publishedYear) payload.publishedYear = Number(payload.publishedYear);
  if (payload.totalCopies) payload.totalCopies = Number(payload.totalCopies);
  try {
    if (id) {
      await api(`/books/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
      toast('Book updated', 'success');
    } else {
      await api('/books', { method: 'POST', body: JSON.stringify(payload) });
      toast('Book added', 'success');
    }
    resetForm('book-form');
    loadBooks();
  } catch (err) {
    toast(err.message, 'error');
  }
});

async function deleteBook(id) {
  if (!confirm('Delete this book?')) return;
  try {
    await api(`/books/${id}`, { method: 'DELETE' });
    toast('Book deleted', 'success');
    loadBooks();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadMembers(search = '') {
  try {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    const { data } = await api(`/members${q}`);
    const body = $('#members-body');
    if (!data.length) {
      body.innerHTML = '<tr><td colspan="5" class="empty">No members yet.</td></tr>';
      return;
    }
    body.innerHTML = data
      .map(
        (m) => `<tr>
          <td>${escapeHtml(m.name)}</td>
          <td>${escapeHtml(m.email)}</td>
          <td><span class="badge badge-${m.role === 'admin' ? 'issued' : 'active'}">${escapeHtml(m.role)}</span></td>
          <td><span class="badge badge-${m.status}">${m.status}</span></td>
          <td><div class="actions">
            <button class="btn-link btn-edit" data-edit-member='${escapeHtml(JSON.stringify(m))}'>Edit</button>
            <button class="btn-link btn-del" data-del-member="${m._id}">Delete</button>
          </div></td>
        </tr>`
      )
      .join('');
    $$('[data-edit-member]', body).forEach((btn) =>
      btn.addEventListener('click', () => fillMemberForm(JSON.parse(btn.dataset.editMember)))
    );
    $$('[data-del-member]', body).forEach((btn) =>
      btn.addEventListener('click', () => deleteMember(btn.dataset.delMember))
    );
  } catch (err) {
    toast(err.message, 'error');
  }
}

function fillMemberForm(member) {
  const f = $('#member-form');
  f.elements.id.value = member._id;
  f.elements.name.value = member.name;
  f.elements.email.value = member.email;
  f.elements.phone.value = member.phone || '';
  f.elements.role.value = member.role;
  f.elements.status.value = member.status;
  f.elements.password.value = '';
  $('#member-form-title').textContent = 'Edit Member';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

$('#member-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = formToObject(e.target);
  const id = payload.id;
  delete payload.id;
  try {
    if (id) {
      await api(`/members/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
      toast('Member updated', 'success');
    } else {
      await api('/members', { method: 'POST', body: JSON.stringify(payload) });
      toast('Member added', 'success');
    }
    resetForm('member-form');
    loadMembers();
  } catch (err) {
    toast(err.message, 'error');
  }
});

async function deleteMember(id) {
  if (!confirm('Delete this member?')) return;
  try {
    await api(`/members/${id}`, { method: 'DELETE' });
    toast('Member deleted', 'success');
    loadMembers();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadLoanFormOptions() {
  try {
    const [{ data: books }, { data: members }] = await Promise.all([
      api('/books?available=true'),
      api('/members?status=active'),
    ]);
    const form = $('#loan-form');
    form.elements.bookId.innerHTML =
      '<option value="">Select a book...</option>' +
      books.map((b) => `<option value="${b._id}">${escapeHtml(b.title)} (${b.availableCopies} avail)</option>`).join('');
    form.elements.memberId.innerHTML =
      '<option value="">Select a member...</option>' +
      members.map((m) => `<option value="${m._id}">${escapeHtml(m.name)} - ${escapeHtml(m.membershipId)}</option>`).join('');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadLoans(status = '') {
  try {
    const q = status ? `?status=${encodeURIComponent(status)}` : '';
    const { data } = await api(`/loans${q}`);
    const body = $('#loans-body');
    if (!data.length) {
      body.innerHTML = '<tr><td colspan="5" class="empty">No loans yet.</td></tr>';
      return;
    }
    body.innerHTML = data
      .map((l) => {
        const book = l.book ? l.book.title : '(deleted book)';
        const member = l.member ? l.member.name : '(deleted member)';
        const due = new Date(l.dueDate).toLocaleDateString();
        let badge = `<span class="badge badge-${l.status}">${l.status}</span>`;
        if (l.isOverdue) badge = '<span class="badge badge-overdue">overdue</span>';
        const action =
          l.status === 'issued'
            ? `<button class="btn-link btn-return" data-return="${l._id}">Return</button>`
            : '';
        return `<tr>
          <td>${escapeHtml(book)}</td>
          <td>${escapeHtml(member)}</td>
          <td>${escapeHtml(due)}</td>
          <td>${badge}</td>
          <td><div class="actions">${action}</div></td>
        </tr>`;
      })
      .join('');
    $$('[data-return]', body).forEach((btn) =>
      btn.addEventListener('click', () => returnLoan(btn.dataset.return, false))
    );
  } catch (err) {
    toast(err.message, 'error');
  }
}

$('#loan-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/loans', { method: 'POST', body: JSON.stringify(formToObject(e.target)) });
    toast('Book issued', 'success');
    e.target.reset();
    loadLoanFormOptions();
    loadLoans($('[data-filter="loans"]').value);
    loadBooks();
  } catch (err) {
    toast(err.message, 'error');
  }
});

async function returnLoan(id, isMember) {
  try {
    await api(`/loans/${id}/return`, { method: 'POST' });
    toast('Book returned', 'success');
    if (isMember) {
      loadMyLoans();
      loadBrowse($('[data-search="browse"]').value);
    } else {
      loadLoans($('[data-filter="loans"]').value);
      loadLoanFormOptions();
      loadBooks();
    }
  } catch (err) {
    toast(err.message, 'error');
  }
}

$('[data-search="browse"]').addEventListener('input', debounce((e) => loadBrowse(e.target.value)));
$('[data-search="books"]').addEventListener('input', debounce((e) => loadBooks(e.target.value)));
$('[data-search="members"]').addEventListener('input', debounce((e) => loadMembers(e.target.value)));
$('[data-filter="loans"]').addEventListener('change', (e) => loadLoans(e.target.value));

(async function boot() {
  if (!getToken()) return showAuth();
  try {
    const { data } = await api('/auth/me');
    enterApp(data);
  } catch (_) {
    showAuth();
  }
})();
