# Library Management System (MongoDB MVP)

A simple but complete **library management system** built with **MongoDB, Mongoose, and Express**, with a small **web panel** for managing books, members, and loans. Built as a course/presentation project demonstrating proper data models and full CRUD operations.

---

## Features

- **Authentication** - JWT login/register; passwords hashed with bcrypt.
- **Roles** - `member` (browse + borrow own books, see own loans) and `admin` (full management).
- **Books** - add, edit, delete, search; tracks total vs. available copies.
- **Members** - register members with auto-generated membership IDs.
- **Loans** - members self-borrow/return; admins issue to anyone; stock kept consistent automatically.
- **Web panel** - login screen -> member portal (Browse / My Loans) or admin panel (Books / Members / Loans).
- **REST API** - every action is also a plain JSON endpoint (Bearer-token protected).
- **Validation & error handling** - schema validation, duplicate detection, friendly errors.

## Demo accounts (after `npm run seed`)

| Role | Email | Password |
|------|-------|----------|
| admin | `admin@example.com` | `admin123` |
| member | `alice@example.com` | `password123` |

---

## Data Models

### Book
| Field | Type | Notes |
|-------|------|-------|
| `title`, `author` | String | required |
| `isbn` | String | required, **unique** |
| `category` | String | default `General` |
| `publishedYear` | Number | range-validated |
| `totalCopies` | Number | total stock |
| `availableCopies` | Number | derived; decremented on loan, restored on return |
| `description` | String | optional |

### Member
| Field | Type | Notes |
|-------|------|-------|
| `name` | String | required |
| `email` | String | required, **unique**, validated |
| `phone` | String | optional |
| `membershipId` | String | auto-generated (`LIB-...`), unique |
| `status` | String | `active` / `inactive` |

### Loan (relationship)
| Field | Type | Notes |
|-------|------|-------|
| `book` | ObjectId -> Book | required (ref) |
| `member` | ObjectId -> Member | required (ref) |
| `issueDate` | Date | defaults to now |
| `dueDate` | Date | required (defaults to +14 days) |
| `returnDate` | Date | set on return |
| `status` | String | `issued` / `returned` |
| `isOverdue` | virtual | computed from `dueDate` + `status` |

---

## Getting Started

### 1. Prerequisites
- Node.js 18+ (tested on Node 22)
- A MongoDB database - either:
  - a local server (`mongodb://127.0.0.1:27017/libman`), or
  - a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster.

### 2. Install
```bash
npm install
```

### 3. Configure
```bash
cp .env.example .env
# then edit .env and set MONGODB_URI
```

### 4. (Optional) Seed sample data
```bash
npm run seed
```

### 5. Run
```bash
npm run dev      # auto-reload during development
# or
npm start        # production-style start
```

Open **http://localhost:3000** for the web panel.

---

## API Reference

Base URL: `http://localhost:3000/api`

All routes except `/auth/*` and `/health` require an `Authorization: Bearer <token>` header. Write operations on books/members and admin-issue require an **admin** token.

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/register` | Sign up (creates a member), returns a token |
| POST | `/auth/login` | Log in `{ email, password }`, returns a token |
| GET | `/auth/me` | Current logged-in user |

### Books
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/books?search=&available=true` | List / search books |
| GET | `/books/:id` | Get one book |
| POST | `/books` | Create a book |
| PUT | `/books/:id` | Update a book |
| DELETE | `/books/:id` | Delete (blocked if on loan) |

### Members
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/members?search=&status=` | List / search members |
| GET | `/members/:id` | Get one member |
| POST | `/members` | Create a member |
| PUT | `/members/:id` | Update a member |
| DELETE | `/members/:id` | Delete (blocked if active loan) |

### Loans
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/loans?status=&member=&book=` | List loans (members see only their own) |
| GET | `/loans/:id` | Get one loan (owner or admin) |
| POST | `/loans/borrow` | Member borrows for themselves `{ bookId, dueDate? }` |
| POST | `/loans` | **Admin** issues to a member `{ bookId, memberId, dueDate? }` |
| POST | `/loans/:id/return` | Return a loan (owner or admin) |

### Example
```bash
# Create a book
curl -X POST http://localhost:3000/api/books \
  -H "Content-Type: application/json" \
  -d '{"title":"Clean Code","author":"Robert Martin","isbn":"978-0132350884","totalCopies":2}'

# Issue it to a member
curl -X POST http://localhost:3000/api/loans \
  -H "Content-Type: application/json" \
  -d '{"bookId":"<BOOK_ID>","memberId":"<MEMBER_ID>"}'
```

---

## Project Structure

```
libman/
├── src/
│   ├── app.js                # Express app (routes + middleware)
│   ├── server.js             # Boot: connect DB + listen
│   ├── config/db.js          # Mongoose connection
│   ├── models/               # Book, Member, Loan schemas
│   ├── controllers/          # CRUD + loan logic
│   ├── routes/               # Express routers
│   ├── middleware/           # asyncHandler + error handler
│   └── seed/seed.js          # Sample data
├── public/                   # Web panel (HTML/CSS/JS)
├── .env.example
└── package.json
```

---

## Notes

- Stock consistency on issue uses an **atomic conditional update** (`findOneAndUpdate` with an `availableCopies > 0` guard) so two simultaneous requests can never over-issue the last copy - a nice MongoDB concurrency pattern.
- This is an MVP for learning purposes; authentication, pagination, and fines are intentionally left out.
